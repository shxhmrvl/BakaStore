# Arkib:Baka

A public digital memorial archive for the Baka multi-community story, 2018–2026.

## Features
- Responsive editorial-style homepage
- Nine-year interactive timeline
- Era collections, people, memories and milestone pages
- Searchable starter memory collection
- Guestbook prototype (browser-local storage)
- GitHub Pages deployment workflow

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## GitHub Pages
1. Push the project to the `main` branch.
2. In repository Settings → Pages, choose **GitHub Actions** as the build and deployment source.
3. The included workflow deploys the `dist` folder after each push.

## Important content note
The year descriptions and memory cards are editorial placeholders, not verified historical claims. Replace them with authentic dates, screenshots, photos, videos and stories. Obtain permission before publishing personal information or identifiable photos.

The guestbook currently stores entries only in the visitor's browser. A shared public guestbook needs a backend database and moderation.
