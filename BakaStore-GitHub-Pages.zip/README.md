# BakaStore — Astro + GitHub Pages

## Jalankan secara lokal

```bash
npm install
npm run dev
```

## Deploy ke GitHub Pages

Workflow GitHub Actions berada di `.github/workflows/deploy.yml`.

1. Pastikan semua fail projek berada di root repository `shxhmrvl/BakaStore`.
2. Push atau upload fail ke branch `main`.
3. Buka repository GitHub → **Settings** → **Pages**.
4. Di bahagian **Build and deployment**, pilih **GitHub Actions** sebagai Source.
5. Buka tab **Actions** dan tunggu workflow `Deploy BakaStore to GitHub Pages` selesai.
6. Website akan tersedia di `https://shxhmrvl.github.io/BakaStore/`.

## Nota

- `base: '/BakaStore'` dalam `astro.config.mjs` diperlukan untuk URL GitHub Pages jenis project site.
- Jika menggunakan custom domain, semak semula nilai `base` dan tetapan domain.
- Harga produk, alamat e-mel, pembayaran, login, database dan sambungan backend masih perlu dilengkapkan.
- Baka AI Terminal pada masa ini ialah demo panduan web, bukan sambungan sebenar kepada server Minecraft.
