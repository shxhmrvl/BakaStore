# BakaStore v3 — Multi-page Astro website

## Included pages
- `/BakaStore/` — Home
- `/BakaStore/hosting/` — Hosting plans
- `/BakaStore/products/` — Digital store with category filters and search
- `/BakaStore/library/` — Resource library with category filters and search
- `/BakaStore/terminal/` — Interactive command guide demo
- `/BakaStore/about/` — About BakaStore
- Unknown paths — custom 404 page

## Publish on GitHub Pages
1. Replace the repository's existing `BakaStore-GitHub-Pages.zip` with this archive, keeping the exact same filename.
2. Keep the repository's `.github/workflows/deploy.yml` workflow already configured to extract the ZIP, install dependencies and build the Astro site.
3. Ensure Settings → Pages → Source is **GitHub Actions**.
4. Commit the ZIP replacement and wait for the Actions run to show both `build` and `deploy` as green.

Astro is configured with `base: '/BakaStore'` and `trailingSlash: 'always'`, so page URLs use the `/BakaStore/page/` format required by GitHub Pages.

## Notes
This is a working static multi-page website. Search, category filters, mobile navigation and the terminal guide demo work in the browser. Hosting order fulfilment, payment processing, customer accounts, live Minecraft server data and AI backend are not connected. Replace the placeholder email and prices before launch.
