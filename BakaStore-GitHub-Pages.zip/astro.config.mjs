import { defineConfig } from 'astro/config';

export default defineConfig({
  output: 'static',
  // GitHub Pages project URL: https://USERNAME.github.io/BakaStore/
  // If you later use a custom domain, change base to '/'.
  base: '/BakaStore',
});
